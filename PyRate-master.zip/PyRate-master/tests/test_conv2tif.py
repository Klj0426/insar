#   This Python module is part of the PyRate software package.
#
#   Copyright 2022 Geoscience Australia
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
"""
This Python module contains tests for the PyRate conv2tif script.
"""
import os
import shutil
import pytest
import glob
import copy
import itertools
from pathlib import Path

import pyrate.configuration
import pyrate.constants as C
from pyrate.core.shared import Ifg, DEM
from pyrate.core import ifgconstants as ifc
from pyrate import conv2tif, prepifg, configuration
from tests.common import manipulate_test_conf, GAMMA_SML_TEST_DIR


def test_dem_and_incidence_not_converted(gamma_params):
    gp_copy = copy.deepcopy(gamma_params)
    gp_copy[C.DEM_FILE] = None
    gp_copy[C.APS_INCIDENCE_MAP] = None
    conv2tif.main(gp_copy)
    inc_tif = glob.glob(os.path.join(GAMMA_SML_TEST_DIR, '*inc.tif'))
    assert len(inc_tif) == 0
    dem_tif = glob.glob(os.path.join(GAMMA_SML_TEST_DIR, '*dem.tif'))
    assert len(dem_tif) == 0


def test_conv2tif_file_types(tempdir, gamma_conf):
    tdir = Path(tempdir())
    params = manipulate_test_conf(gamma_conf, tdir)
    params[C.COH_MASK] = 1
    output_conf_file = 'conf.conf'
    output_conf = tdir.joinpath(output_conf_file)
    pyrate.configuration.write_config_file(params=params, output_conf_file=output_conf)
    params_s = configuration.Configuration(output_conf).__dict__
    conv2tif.main(params_s)
    ifg_files = list(Path(tdir.joinpath(params_s[C.OUT_DIR])).glob('*_ifg.tif'))
    coh_files = list(Path(tdir.joinpath(params_s[C.OUT_DIR])).glob('*_coh.tif'))
    dem_file = list(Path(tdir.joinpath(params_s[C.GEOMETRY_DIR])).glob('*_dem.tif'))[0]
    # assert coherence and ifgs have correct metadata
    for i in itertools.chain(*[ifg_files, coh_files]):
        ifg = Ifg(i)
        ifg.open()
        md = ifg.meta_data
        if i.name.endswith('_ifg.tif'):
            assert md[ifc.DATA_TYPE] == ifc.ORIG
            continue
        if i.name.endswith('_coh.tif'):
            assert md[ifc.DATA_TYPE] == ifc.COH
            continue

    # assert dem has correct metadata
    dem = DEM(dem_file.as_posix())
    dem.open()
    md = dem.dataset.GetMetadata()
    assert md[ifc.DATA_TYPE] == ifc.DEM
    shutil.rmtree(tdir)


def test_tifs_placed_in_out_dir(gamma_params):
    # Test no tifs in obs dir
    tifs = glob.glob(os.path.join(gamma_params[C.INTERFEROGRAM_DIR], '*.tif'))
    assert len(tifs) == 0
    # Test tifs in obs dir
    conv2tif.main(gamma_params)
    tifs = glob.glob(os.path.join(gamma_params[C.INTERFEROGRAM_DIR], '*.tif')) + \
        glob.glob(os.path.join(gamma_params[C.COHERENCE_DIR], '*.tif')) + \
        glob.glob(os.path.join(gamma_params[C.GEOMETRY_DIR], '*.tif')) \

    assert len(tifs) == 35


def test_num_gamma_tifs_equals_num_unws(gamma_params):
    gtifs = conv2tif.main(gamma_params)
    # 17 unws + dem + 17 cohfiles
    assert len(gtifs) == 35

    for g, _ in gtifs:   # assert all output from conv2tfi are readonly
        assert Path(g).stat().st_mode == 33060

def test_num_roipac_tifs_equals_num_unws(roipac_params):
    gtifs = conv2tif.main(roipac_params)
    # 17 unws + dem
    assert len(gtifs) == 18


def test_conversion_not_recomputed(gamma_params):

    """
    If a gtif already exists, conv2tif will return None instead
    of path to the gtif.
    """
    conv2tif.main(gamma_params)
    gtifs_and_conversion_bool = conv2tif.main(gamma_params)
    assert all([not b for gt, b in gtifs_and_conversion_bool])


def test_no_tifs_exits(gamma_params):
    with pytest.raises(Exception):
        prepifg.main(gamma_params)


def test_tifs_succeeds(gamma_params):
    conv2tif.main(gamma_params)
    prepifg.main(gamma_params)
