class IfgDummy:
    def __init__(self, ifg_path):
        self.tmp_sampled_path = ifg_path