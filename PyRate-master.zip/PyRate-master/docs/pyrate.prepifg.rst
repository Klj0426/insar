PyRate Prepifg Script
=========================

.. automodule:: pyrate.prepifg
    :members:
    :undoc-members:
    :show-inheritance:
