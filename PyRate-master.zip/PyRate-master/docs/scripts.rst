PyRate Scripts
==============

.. toctree::
   :maxdepth: 4

   pyrate.conv2tif
   pyrate.prepifg
   pyrate.correct
   pyrate.merge
   pyrate.main
