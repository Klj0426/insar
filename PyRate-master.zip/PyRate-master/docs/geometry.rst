Geometry Module
===============

.. automodule:: pyrate.core.geometry
   :members:
