=======
Credits
=======

Development Lead
----------------

`PyRate` has been developed by `Geoscience Australia <http://www.ga.gov.au>`__
with some initial assistance from the `National Computational Infrastructure <http://nci.org.au/>`__.

Contact: `Geoscience Australia InSAR team <mailto:insar@ga.gov.au>`__

Contributors
------------

Thanks to `all the contributors`_ who helped to build the ship and raise the sail, Arrrr!

.. _`all the contributors`: https://github.com/GeoscienceAustralia/PyRate/graphs/contributors

* Sudipta Basak (GA)
* Ben Davies (NCI)
* Alistair Deane (GA)
* Thomas Fuhrmann (GA)
* Syed Sheece Raza Gardezi (GA)
* Matt Garthwaite (GA)
* Simon Knapp (GA)
* Sarah Lawrie (GA)
* Jonathan Mettes (GA)
* Negin Moghaddam (GA)
* Brenainn Moushall (GA)
* Vanessa Newey (GA)
* Chandrakanta Ojha (GA)
* Garrick Paskos (GA)
* Nahidul Samrat (GA)
* Richard Taylor (GA)
