Algorithm Module
================

.. automodule:: pyrate.core.algorithm
   :members: