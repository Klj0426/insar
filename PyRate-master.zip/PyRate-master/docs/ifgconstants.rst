Ifgconstants Module
===================

.. automodule:: pyrate.core.ifgconstants
    :members:
