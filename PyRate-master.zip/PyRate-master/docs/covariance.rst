Covariance Module
=====================

.. automodule:: pyrate.core.covariance
   :members:
