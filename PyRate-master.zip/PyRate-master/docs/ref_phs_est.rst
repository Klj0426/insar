Reference Phase Calculation Module
==================================

.. automodule:: pyrate.core.ref_phs_est
   :members: