GAMMA Module
============

.. automodule:: pyrate.core.gamma
   :members: