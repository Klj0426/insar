PyRate Main Script
==================

.. automodule:: pyrate.main

   .. rubric:: Functions
   .. autosummary::

      conv2tif
      prepifg
      correct
      timeseries
      stack
      merge
