Stacking Module
===============

.. automodule:: pyrate.core.stack
   :members:
