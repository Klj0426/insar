ROI_PAC Module
==============

.. automodule:: pyrate.core.roipac
   :members:
