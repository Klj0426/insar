Orbital Error Correction Module
===============================

.. automodule:: pyrate.core.orbital
   :members: