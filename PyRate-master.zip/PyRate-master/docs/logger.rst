Logging Module
==============

.. automodule:: pyrate.core.logger
   :members:
