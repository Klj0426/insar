PyRate Merge Script
===================

.. automodule:: pyrate.merge
    :members:
    :undoc-members:
    :show-inheritance:
