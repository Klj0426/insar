Atmospheric Phase Screen Module
===============================

.. automodule:: pyrate.core.aps
   :members:
