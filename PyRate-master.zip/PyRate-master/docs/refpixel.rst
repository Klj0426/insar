Reference Pixel Calculation Module
==================================

.. automodule:: pyrate.core.refpixel
   :members: