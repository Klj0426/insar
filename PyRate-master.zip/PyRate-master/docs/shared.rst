Shared Module
=============

.. automodule:: pyrate.core.shared
   :members: